<template>
  <div class="page-content">
    <slot />
  </div>
</template>

<script>
export default {
  props: {},

  data() {
    return {};
  },
};
</script>

<style lang="scss">

</style>