<template>
  <v-icon :title="text" small>mdi-help-circle-outline</v-icon>
</template>

<script>
export default {
  props: {
    text: String,
  },

  data() {
    return {};
  },
};
</script>

<style scoped>
</style>