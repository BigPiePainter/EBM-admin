module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],
  publicPath: '/'
}
